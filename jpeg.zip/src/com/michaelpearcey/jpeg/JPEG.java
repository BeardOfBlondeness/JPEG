package com.michaelpearcey.jpeg;

import Huffman.InputWorkaround;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

public class JPEG implements Serializable {

    private DCTPixel[][] pixels;

    public JPEG(DCTPixel[][] pixels) {
        this.pixels = pixels;
    }

    public DCTPixel[][] getPixels() {
        return pixels;
    }

    public void encode(String input, String output) {
        try {
            FileInputStream in = new FileInputStream(input);
            OutputStream out = new FileOutputStream(output);
            InputWorkaround inw = new InputWorkaround(in);
            new Huffman.Encoder(inw, out, true);
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    public void save(String path) {
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        try {
            fos = new FileOutputStream(path);
            out = new ObjectOutputStream(fos);
            out.writeObject(pixels);

            out.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static JPEG decodeBytes(String path) throws IOException {
        System.out.println("DECODING BYTES");
        byte[] array = Files.readAllBytes(Paths.get(path));
        String s = new String(array);
        DCTPixel[][] pixels = new DCTPixel[1][1];
        int identifier = 0;
        String widthS = "";
        String heightS = "";
        String appendedString = "";
        int type = 0;
        int x = 0;
        int y = 0;
        System.out.println(s);
        for(int i = 0; i < s.length(); i++) {
            System.out.println(identifier);
            System.out.println(widthS + " " + heightS);
            if(identifier==0) {
                if(s.charAt(i)!= ' ') widthS+=s.charAt(i);
                else identifier++;
            } else if(identifier==1) {
                if(s.charAt(i)!= ' ') heightS+=s.charAt(i);
                else  {
                    identifier++;
                    System.out.println(widthS + " " + heightS);
                    pixels = new DCTPixel[Integer.parseInt(widthS)][Integer.parseInt(heightS)];
                }
            } else {
                if(s.charAt(i) != ' ') {
                    appendedString+= s.charAt(i);
                } else if(type == 0) {
                    pixels[x][y].setPixelY(Double.parseDouble(appendedString));
                    type++;
                } else if(type == 1) {
                    pixels[x][y].setPixelCB(Double.parseDouble(appendedString));
                    type++;
                } else {
                    pixels[x][y].setPixelCR(Double.parseDouble(appendedString));
                    type = 0;
                    identifier++;
                    x++;
                }
                if(identifier%Integer.parseInt(widthS) == 0 && identifier > 0) {
                    x = 0;
                    y++;
                }
            }
        }
        System.out.println("DONE DECODING");
        return new JPEG(pixels);
    }

    public void encodeString(String input, String file) {
        byte[] b = input.getBytes();
        try {
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(b);
            //fos.close(); There is no more need for this line since you had created the instance of "fos" inside the try. And this will automatically close the OutputStream
        } catch(Exception e) {
            e.printStackTrace();
        }
        /**System.out.println("ENCODING BYTES");
        Map<Character, Integer> charFreq = HuffmanCoding.getCharFrequency(input);
        HuffmanNode root = HuffmanCoding.buildTree(charFreq);
        Map<Character, String> charCode = HuffmanCoding.createHuffmanCodes(charFreq.keySet(), root);
        String encodedMessage = encodeMessage(charCode, input);

        byte[] b = encodedMessage.getBytes();
        try {
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(b);
            //fos.close(); There is no more need for this line since you had created the instance of "fos" inside the try. And this will automatically close the OutputStream
        } catch(Exception e) {
            e.printStackTrace();
        }
        System.out.println("DONE ENCODING");**/
    }

    private static String encodeMessage(Map<Character, String> charCode, String input) {
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < input.length(); i++) {
            stringBuilder.append(charCode.get(input.charAt(i)));
        }
        return stringBuilder.toString();
    }

    public String toString() {
        String ret = pixels.length + " " + pixels[1].length;
        for(int i = 0; i < pixels.length; i++) {
            for(int j = 0; j < pixels[1].length; j++) {
                ret+= " " + pixels[i][j].getPixelY() + " " + pixels[i][j].getPixelCB() + " " + pixels[i][j].getPixelCR();
            }
        }
        return ret;
    }

    public double getObjectSize() {
        double sizeOfPixels = pixels.length;
        double total = 3*sizeOfPixels*Double.SIZE/8;
        double sizeInKB = total/1000;
        return sizeInKB*sizeInKB;
    }
}
