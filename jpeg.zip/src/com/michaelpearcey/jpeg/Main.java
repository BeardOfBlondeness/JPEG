package com.michaelpearcey.jpeg;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.instrument.Instrumentation;

import Huffman.InputWorkaround;

public class Main {

    static final int div = 256;
    final static int size = 8;
    static DCT dct = new DCT();
    static int MSEs[];
    static double sizeRatio[];

    static double[][] quantizationTable = { {16, 11, 10, 16, 24, 40, 51, 61},
                                            {12, 12, 14, 19, 26, 58, 60, 55},
                                            {14, 13, 16, 24, 40, 57, 69, 56},
                                            {14, 17, 22, 29, 51, 87, 80, 62},
                                            {18, 22, 37, 56, 68, 109, 103, 77},
                                            {24, 35, 55, 64, 81, 104, 113, 92},
                                            {49, 64, 78, 87, 103, 121, 120, 101},
                                            {72, 92, 95, 98, 112, 100, 103, 99}};

    public static void main(String[] args) throws IOException {
        MSEs = new int[6];
        sizeRatio = new double[6];
        encodeImages();
        decodeImages();
        for(int i = 0; i < 6; i++) {
            System.out.println("MSE : " + MSEs[i] + " ----- Size Ratio: " + sizeRatio[i]);
        }
    }

    static BufferedImage decodeAll(DCTPixel[][] pixels) {
        BufferedImage img = new BufferedImage(pixels.length, pixels[1].length, BufferedImage.TYPE_INT_RGB);
        for(int x = 0; x < pixels.length; x+=size) {
            for(int y = 0; y < pixels[1].length; y+=size) {
                double[][] toDCTY = new double[size][size];
                double[][] toDCTCB = new double[size][size];
                double[][] toDCTCR = new double[size][size];
                for(int i = x; i < x+size; i++) {
                    for(int j = y; j < y+size; j++) {
                        toDCTY[i-x][j-y] = pixels[i][j].getPixelY();
                        toDCTCB[i-x][j-y] = pixels[i][j].getPixelCB();
                        toDCTCR[i-x][j-y] = pixels[i][j].getPixelCR();
                    }
                }
                toDCTY = dct.applyIDCT(toDCTY);
                toDCTCB = dct.applyIDCT(toDCTCB);
                toDCTCR = dct.applyIDCT(toDCTCR);
                for(int i = x; i < x+size; i++) {
                    for(int j = y; j < y+size; j++) {
                       Color c = new Color((int)toDCTY[i-x][j-y]+127, (int)toDCTCB[i-x][j-y]+127, (int)toDCTCR[i-x][j-y]+127);
                       img.setRGB(i, j, c.getRGB());
                    }
                }
            }
        }
        for(int i = 0; i < img.getWidth(); i++) {
            for(int j = 0; j < img.getHeight(); j++) {
                Color c = new Color(img.getRGB(i, j));
                img.setRGB(i, j, getColorFromYCbCr(c.getRed(), c.getGreen(), c.getBlue()));
            }
        }
        return img;
    }

    static void decodeImages() throws IOException {
        for(int imageCount = 1; imageCount < 7; imageCount++) {
            System.out.println("DECODING IMAGES");
            FileInputStream in = new FileInputStream("encoded/" + imageCount + ".encoded");
            OutputStream out = new FileOutputStream("decoded/" + imageCount + ".tempFile");
            new Huffman.Decoder(in, out, true);

            JPEG p;
            DCTPixel[][] pixels;
            FileInputStream fis = null;
            ObjectInputStream ins = null;
            try {
               fis = new FileInputStream("decoded/" + imageCount + ".tempFile");
                ins = new ObjectInputStream(fis);
                p = new JPEG((DCTPixel[][]) ins.readObject());
                pixels = p.getPixels();
                System.out.println(pixels.length);
                //in.close();
                BufferedImage img = decodeAll(pixels);
                File outputfile = new File("output/image" + imageCount + ".bmp");
                ImageIO.write(img, "bmp", outputfile);
                File outputfiles = new File("output/imageJPG" + imageCount + ".jpg");
                ImageIO.write(img, "jpg", outputfiles);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            System.out.println("Image : " + imageCount + " MSE: " + getMSE(imageCount));
        }
    }

    static BufferedImage fillPPM(PPMReader ppm) {
        BufferedImage img = new BufferedImage(ppm.getWidth(), ppm.getHeight(), BufferedImage.TYPE_INT_RGB);
        for(int y = 0; y < ppm.getHeight(); y++) {
            for(int x = 0; x < ppm.getWidth(); x++) {
                Color temp = new Color(ppm.getRGBAt(y, x));
                int r = temp.getRed();
                int g = temp.getGreen();
                int b = temp.getBlue();
                Color c = getYCBCR(r, g, b);
                int newR = c.getRed();
                int newG = c.getGreen();
                int newB = c.getBlue();
                Color newC = new Color(newR, newG, newB);
                img.setRGB(x, y, newC.getRGB());
            }
        }
        return img;
    }

    static void encodeImages() throws IOException {
        for(int imageCount = 1; imageCount < 7; imageCount++) {
            System.out.println("ENCODING IMAGE " + imageCount);
            PPMReader ppm = new PPMReader("res/" + imageCount + ".ppm");
            BufferedImage img = fillPPM(ppm);
            DCTPixel[][] pixels = new DCTPixel[ppm.getWidth()][ppm.getHeight()];
            double[][] matrixY;
            double[][] matrixCB;
            double[][] matrixCR;
            for(int y = 0; y < img.getHeight(); y+=size) {
                for(int x = 0; x < img.getWidth(); x+=size) {
                    matrixY = new double[size][size];
                    matrixCB = new double[size][size];
                    matrixCR = new double[size][size];
                    for(int i = x; i < x+size; i++) {
                        for(int j = y; j < y+size; j++) {
                            img.setRGB(i, j, (int)Math.round((double)img.getRGB(i, j)));
                            Color c = new Color(img.getRGB(i, j));
                            matrixY[i-x][j-y] = (double)c.getRed()-127;
                            matrixCB[i-x][j-y] = (double)c.getGreen()-127;
                            matrixCR[i-x][j-y] = (double)c.getBlue()-127;
                        }
                    }
                    matrixY = dct.applyDCT(matrixY);
                    matrixCB = dct.applyDCT(matrixCB);
                    matrixCR = dct.applyDCT(matrixCR);
                    for(int i = x; i < x+size; i++) {
                        for(int j = y; j < y+size; j++) {
                            matrixY[i-x][j-y] = matrixY[i-x][j-y];
                            matrixCB[i-x][j-y] = matrixCB[i-x][j-y];
                            matrixCR[i-x][j-y] = matrixCR[i-x][j-y];
                            DCTPixel pix = new DCTPixel(matrixY[i-x][j-y], matrixCB[i-x][j-y], matrixCR[i-x][j-y]);
                            pixels[i][j] = pix;
                        }
                    }
                }
            }

            JPEG jpg = new JPEG(pixels);
            System.out.println("Number of bytes: " + jpg.getObjectSize()*1000 + "\nNumber of KB: " + jpg.getObjectSize() + "\nNumber of MB: " + jpg.getObjectSize()/1000);
            sizeRatio[imageCount-1] = 2500/jpg.getObjectSize();
            System.out.println("Finished Encoding image " + imageCount);
            jpg.save("test/" + imageCount + ".tempFile");
            jpg.encode("test/" + imageCount + ".tempFile", "encoded/" + imageCount + ".encoded");
        }
    }

    static Color getYCBCR(int rInt, int gInt, int bInt) {
        double r = (double)rInt/255;
        double g = (double)gInt/255;
        double b = (double)bInt/255;
        double eY = (0.299*r)+(0.587*g)+(0.114*b);
        double eCb = (-0.169*r)-(0.331*g)+(0.5*b);
        double eCr = (0.5*r) - (0.419*g) - (0.081*b);
        int y = (int)Math.round((219*eY)+16);
        int Cb = (int)Math.round((224*eCb) + 128);
        int Cr = (int)Math.round((224*eCr) + 128);

        if(y > 255) y = 255;
        if(Cb > 255) Cb = 255;
        if(Cr > 255) Cr = 255;
        if(y < 0) y = 0;
        if(Cb < 0) Cb = 0;
        if(Cr < 0) Cr = 0;
        return new Color(y, Cb, Cr);
    }

    static int getColorFromYCbCr(int y, int cb, int cr)
    {
        y = y-16;
        cb = cb-128;
        cr = cr-128;
        double rd = (1.164*(double)y) + (1.793 * (double)cr);
        double gd = (1.164*(double)y) - (0.213*(double)cb) - (0.533*(double)cr);
        double bd = (1.164*(double)y) + (2.112*(double)cb);
        int r = (int)Math.round(rd);
        int g = (int)Math.round(gd);
        int b = (int)Math.round(bd);
        if(r < 0) r = 0;
        if(g < 0) g = 0;
        if(b < 0) b = 0;
        if(r > 255) r = 255;
        if(g > 255) g = 255;
        if(b > 255) b = 255;
        return new Color(r, g, b).getRGB();
    }

    static double getMSE(int imgNum) throws IOException {
        BufferedImage imgB = ImageIO.read(new File("output/image" + imgNum + ".bmp"));
        PPMReader ppm = new PPMReader("res/" + imgNum + ".ppm");
        BufferedImage imgOriginal = fillPPM(ppm);
        int sumR = 0;
        int sumG = 0;
        int sumB = 0;
        for(int i = 0; i < imgB.getWidth(); i++) {
            for(int j = 0; j < imgB.getHeight(); j++) {
                Color cb = new Color(imgB.getRGB(i, j));
                Color co = new Color(imgOriginal.getRGB(i, j));
                sumR += Math.pow(Math.abs((cb.getRed() - co.getRed())), 2);
                sumG += Math.pow(Math.abs((cb.getGreen() - co.getGreen())), 2);
                sumB += Math.pow(Math.abs((cb.getBlue() - co.getBlue())), 2);
            }
        }
        int total = (sumR+sumG+sumB)/3;
        MSEs[imgNum-1] = total/(imgB.getWidth()*imgB.getHeight());
        return total/(imgB.getWidth()*imgB.getHeight());
    }
}