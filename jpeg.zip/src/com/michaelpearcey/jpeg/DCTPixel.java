package com.michaelpearcey.jpeg;

import java.io.Serializable;

public class DCTPixel implements Serializable {

    private double pixelY;
    private double pixelCB;
    private double pixelCR;

    public DCTPixel(double pixelY, double pixelCB, double pixelCR) {
        this.pixelY = pixelY;
        this.pixelCB = pixelCB;
        this.pixelCR = pixelCR;
    }

    public double getPixelY() {
        return pixelY;
    }

    public void setPixelY(double pixelY) {
        this.pixelY = pixelY;
    }

    public double getPixelCB() {
        return pixelCB;
    }

    public void setPixelCB(double pixelCB) {
        this.pixelCB = pixelCB;
    }

    public double getPixelCR() {
        return pixelCR;
    }

    public void setPixelCR(double pixelCR) {
        this.pixelCR = pixelCR;
    }
}
