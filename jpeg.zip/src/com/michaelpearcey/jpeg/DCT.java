package com.michaelpearcey.jpeg;

import java.util.Random;

public class DCT {
    private static final int N = 8;
    private double[][] c = new double[N][N];

    public DCT() {
        this.initializeCoefficients();
    }

    private void initializeCoefficients() {
        /**for (int i=1;i<N;i++) {
            c[i]=1;
        }
        c[0]=1/Math.sqrt(2.0);
        **/
        final double value = 1/Math.sqrt(2.0);

        for (int i=1; i<N; i++)
        {
            for (int j=1; j<N; j++)
            {
                c[i][j]=1;
            }
        }

        for (int i=0; i<N; i++)
        {
            c[i][0] = value;
            c[0][i] = value;
        }
        c[0][0] = 0.5;
    }

    public double[][] applyDCT(double[][] f) {
        /**double[][] F = new double[N][N];
        for (int u=0;u<N;u++) {
            for (int v=0;v<N;v++) {
                double sum = 0.0;
                for (int i=0;i<N;i++) {
                    for (int j=0;j<N;j++) {
                        sum+=Math.cos(((2*i+1)/(2.0*N))*u*Math.PI)*Math.cos(((2*j+1)/(2.0*N))*v*Math.PI)*f[i][j];
                    }
                }
                sum*=((c[u]*c[v])/4.0);
                F[u][v]=sum;
            }
        }
        return F;**/
        final int N = f.length;
        final double mathPI = Math.PI;
        final int halfN = N/2;
        final double doubN = 2.0*N;

        double[][] output = new double[N][N];

        for (int u=0; u<N; u++)
        {
            double temp_u = u*mathPI;
            for (int v=0; v<N; v++)
            {
                double temp_v = v*mathPI;
                double sum = 0.0;
                for (int x=0; x<N; x++)
                {
                    int temp_x = 2*x+1;
                    for (int y=0; y<N; y++)
                    {
                        sum += f[x][y] * Math.cos((temp_x/doubN)*temp_u) * Math.cos(((2*y+1)/doubN)*temp_v);
                    }
                }
                sum *= c[u][v]/ halfN;
                output[u][v] = sum;
            }
        }
        return output;
    }

    public double[][] applyIDCT(double[][] F) {
        /**double[][] f = new double[N][N];
        for (int i=0;i<N;i++) {
            for (int j=0;j<N;j++) {
                double sum = 0.0;
                for (int u=0;u<N;u++) {
                    for (int v=0;v<N;v++) {
                        sum+=(c[u]*c[v])/4.0*Math.cos(((2*i+1)/(2.0*N))*u*Math.PI)*Math.cos(((2*j+1)/(2.0*N))*v*Math.PI)*F[u][v];
                    }
                }
                f[i][j]=Math.round(sum);
            }
        }
        return f;**/

        final int N = F.length;
        final double mathPI = Math.PI;
        final int halfN = N/2;
        final double doubN = 2.0*N;

        double[][] output = new double[N][N];


        for (int x=0; x<N; x++)
        {
            int temp_x = 2*x+1;
            for (int y=0; y<N; y++)
            {
                int temp_y = 2*y+1;
                double sum = 0.0;
                for (int u=0; u<N; u++)
                {
                    double temp_u = u*mathPI;
                    for (int v=0; v<N; v++)
                    {
                        sum += c[u][v] * F[u][v] * Math.cos((temp_x/doubN)*temp_u) * Math.cos((temp_y/doubN)*v*mathPI);
                    }
                }
                sum /= halfN;
                output[x][y] = sum;
            }
        }
        return output;
    }


    public static void main(String[] args) {
        System.out.println("Testing: " );
        double[][] test = new double[8][8];
        Random r = new Random();
        for(int i = 0; i < 8; i++) {
            for(int j = 0; j < 8; j++) {
                test[i][j] = r.nextDouble();
                System.out.print(test[i][j] + "\t");
            }
            System.out.print("\n");
        }

        DCT dct = new DCT();
        test = dct.applyDCT(test);
        System.out.println("\n\n\n\n\n\n\n");
        for(int i = 0; i < 8; i++) {
            for(int j = 0; j < 8; j++) {
                System.out.print(test[i][j] + "\t");
            }
            System.out.print("\n");
        }

        test = dct.applyIDCT(test);
        System.out.println("\n\n\n\n\n\n\n");
        for(int i = 0; i < 8; i++) {
            for(int j = 0; j < 8; j++) {
                System.out.print(test[i][j] + "\t");
            }
            System.out.print("\n");
        }
    }
}